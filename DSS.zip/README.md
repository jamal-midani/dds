# نظام دعم اتخاذ القرار للتوظيف

نظام معلومات إداري يساعد الجهة المختصة على اتخاذ القرار الأنسب لاختيار مدير عام لشركة من بين عدة مرشحين.

## المميزات

### واجهة المستخدم العامة
- عرض الوظائف المتاحة
- نموذج تقديم طلب توظيف شامل
- رفع السيرة الذاتية (PDF)
- رسالة نجاح بعد التقديم

### لوحة التحكم (Filament Admin Panel)
- إدارة الوظائف (إضافة، تعديل، حذف، تفعيل/إلغاء تفعيل)
- إدارة المتقدمين (عرض، بحث، تصفية، تقييم)
- نظام دعم اتخاذ القرار مع تحليل المتقدمين
- ترتيب المتقدمين حسب معايير مختلفة

### المميزات المتقدمة
- **نظام النقاط التلقائي**: تقييم تلقائي للمتقدمين بناءً على:
  - الخبرة (40%)
  - المؤهل العلمي (30%)
  - المهارات (20%)
  - العمر (10%)
- **تكامل Gemini AI**: 
  - تحليل الخبرات والمؤهلات
  - إعطاء اقتراحات حول أفضل 3 متقدمين
  - كتابة ملخص تلقائي للمتقدم
- **Smart Filters**: تصفية المتقدمين حسب معايير متعددة

## المتطلبات التقنية

- PHP 8.2+
- Laravel 12
- MySQL
- Composer
- Node.js & NPM

## التثبيت

1. استنساخ المشروع:
```bash
git clone <repository-url>
cd DSS
```

2. تثبيت التبعيات:
```bash
composer install
npm install
```

3. إعداد ملف البيئة:
```bash
cp .env.example .env
php artisan key:generate
```

4. إعداد قاعدة البيانات في `.env`:
```env
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=your_database
DB_USERNAME=your_username
DB_PASSWORD=your_password
```

5. إضافة مفتاح Gemini API (اختياري):
```env
GEMINI_API_KEY=your_gemini_api_key
```

6. تشغيل Migrations:
```bash
php artisan migrate
```

7. إنشاء مستخدم Admin:
```bash
php artisan make:filament-user
```

8. بناء Assets:
```bash
npm run build
```

9. تشغيل الخادم:
```bash
php artisan serve
```

## الوصول

- **الموقع العام**: http://localhost:8000
- **لوحة التحكم**: http://localhost:8000/admin

## البنية

```
app/
├── Filament/Resources/     # Filament Resources
├── Http/Controllers/       # Controllers
├── Models/                 # Eloquent Models
└── Services/               # Service Layer
    ├── ApplicantService.php
    ├── GeminiService.php
    ├── PositionService.php
    └── ScoringService.php

resources/
├── views/
│   ├── layouts/           # Layouts
│   └── public/            # Public Views
└── views/filament/        # Filament Views

database/
└── migrations/            # Database Migrations
```

## الاستخدام

### إضافة وظيفة جديدة
1. تسجيل الدخول إلى لوحة التحكم
2. الانتقال إلى "الوظائف"
3. النقر على "إضافة وظيفة جديدة"
4. ملء البيانات المطلوبة

### عرض المتقدمين
1. الانتقال إلى "المتقدمين"
2. استخدام الفلاتر للبحث والتصفية
3. عرض تفاصيل المتقدم بالنقر على "تعديل"

### دعم اتخاذ القرار
1. الانتقال إلى "دعم اتخاذ القرار"
2. اختيار المنصب المطلوب
3. اختيار معيار الترتيب
4. عرض أفضل 3 متقدمين (Gemini AI)

## الترخيص

MIT License
